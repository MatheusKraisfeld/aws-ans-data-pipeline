import os


def ans_clean_data(event, context):
    pass
